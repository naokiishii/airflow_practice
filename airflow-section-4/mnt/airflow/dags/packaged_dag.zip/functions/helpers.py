def first_helper_task():
    print("Hello from first helper task")

def second_helper_task():
    print("Hello from second helper task")

def third_helper_task():
    print("Hello from third helper task")